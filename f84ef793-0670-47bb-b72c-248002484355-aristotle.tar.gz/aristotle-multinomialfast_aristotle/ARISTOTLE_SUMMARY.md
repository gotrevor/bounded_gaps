# Summary of changes for run 3aba523a-8367-4d76-978f-80b78c55a894
Both theorems in `MultinomialFast.lean` have been proved — no `sorry` remains.

**`multinomialFast_eq`**: Proved by induction on the list `l`. The base case is immediate (`multinomialFast f [] = 1 = Nat.multinomial ∅ f`). The inductive step uses `Nat.multinomial_insert` and `Finset.sum_insert` to unfold the Mathlib multinomial at `insert x xs.toFinset`, matching the recursive definition of `multinomialFast`, with `List.sum_toFinset` bridging the list sum `(xs.map f).sum` to the finset sum `∑ i in xs.toFinset, f i`.

**`multinomialFast_toList_eq`**: Follows directly from `multinomialFast_eq` applied to `s.toList` (which satisfies `Nodup` via `Finset.nodup_toList`), then rewriting `s.toList.toFinset = s` via `Finset.toList_toFinset`.

No axioms were added; both proofs use only standard Mathlib imports. The file compiles cleanly.